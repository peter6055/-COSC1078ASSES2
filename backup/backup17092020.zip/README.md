Project Info:

Group: 20

Group Name: #20.5

GitHub Repo URL: https://github.com/peter6055/COSC1078ASSES2/ 

GitHub Pages URL: https://peter6055.github.io/COSC1078ASSES2/


================ Reference list ================ 

Templete:
- [1]"Avana Free Website Template | Free CSS Templates | Free CSS", Free-css.com, 2020. [Online]. Available: https://www.free-css.com/free-css-templates/page225/avana. [Accessed: 17- Sep- 2020].

Images: 
- [2]"What Is Cloud Computing & How Does 'The Cloud' Work?", Fastmetrics Business Blog, 2020. [Online]. Available: https://www.fastmetrics.com/blog/tech/what-is-cloud-computing/. [Accessed: 17- Sep- 2020].

- [3]"Machine learning helps UK utility speed up leakage detection", Aquatechtrade.com, 2020. [Online]. Available: https://www.aquatechtrade.com/news/water-treatment/machine-learning-helps-uk-water-utilities-to-tackle-leakage/. [Accessed: 17- Sep- 2020].

- [4]"Cyber Security—Advancing through AI - IEEE Innovation at Work", IEEE Innovation at Work, 2020. [Online]. Available: https://innovationatwork.ieee.org/cyber-security-advancing-through-ai/. [Accessed: 17- Sep- 2020].

- [5]"Autonomous Vehicles Run Into Serious Roadblocks | PYMNTS.com", PYMNTS.com, 2020. [Online]. Available: https://www.pymnts.com/innovation/2019/autonomous-vehicles-run-into-serious-roadblocks/. [Accessed: 17- Sep- 2020].

- [6]"Cloud Infrastructure: How Does Cloud Computing Work? | Robots.net", Robots.net, 2020. [Online]. Available: https://robots.net/how-to-guide/cloud-infrastructure-how-it-works/. [Accessed: 17- Sep- 2020].

- [7]"IBM Bluemix IoT Platform | IoT5.net", IOT5.net, 2020. [Online]. Available: https://iot5.net/ibm-bluemix-iot-platform/. [Accessed: 17- Sep- 2020].


IT Technology:

  Clouds, services, server:
   - Google Cloud. 2020. Spotify Case Study  |  Google Cloud. [ONLINE] Available at: https://cloud.google.com/customers/spotify. [Accessed 17 September 2020].

   - Amazon Web Services, Inc.. 2020. Amazon SageMaker 客户 – Amazon Web Services (AWS). [ONLINE] Available at: https://aws.amazon.com/cn/sagemaker/customers/. [Accessed 17 September 2020].

   - Security at Grammarly. 2020. Security at Grammarly. [ONLINE] Available at: https://www.grammarly.com/security-practices. [Accessed 17 September 2020].

   - Google Cloud. 2020. Cloud Computing Services  |  Google Cloud. [ONLINE] Available at: https://cloud.google.com. [Accessed 17 September 2020].

   - Microsoft Azure. 2020. What is cloud computing? A beginner’s guide | Microsoft Azure. [ONLINE] Available at: https://azure.microsoft.com/en-au/overview/what-is-cloud-computing/. [Accessed 17 September 2020].

   - Google Cloud. 2020. App Engine Application Platform  |  Google Cloud. [ONLINE] Available at: https://cloud.google.com/appengine. [Accessed 17 September 2020].

   - Google Cloud. 2020. Compute Engine: Virtual Machines (VMs)  |  Google Cloud. [ONLINE] Available at: https://cloud.google.com/compute. [Accessed 17 September 2020].

   - Amazon Web Services, Inc.. 2020. Cloud Object Storage | Store & Retrieve Data Anywhere | Amazon Simple Storage Service (S3). [ONLINE] Available at: https://aws.amazon.com/s3/?nc1=h_ls. [Accessed 17 September 2020].


  Machine learning:
   - Siewert, J. (n.d.). HEATH TERRY PODCAST. [online] Available at: https://www.goldmansachs.com/insights/podcasts/episodes/03-03-2020-heath-terry-f/transcript.pdf.
   
   - Azure Machine Learning | Microsoft Azure 2019, Microsoft.com, Microsoft Azure.
   
   - deeplearning.ai. (2018). deeplearning.ai. [online] Available at: https://www.deeplearning.ai/.
   
   - Automating machine learning with a joint selection framework n.d., MIT-IBM Watson AI Lab, viewed 9 September 2020, <https://mitibmwatsonailab.mit.edu/research/blog/an-admm-based-framework-for-automl-pipeline-configuration/>.
   
   - Imitation learning from observations n.d., MIT-IBM Watson AI Lab, viewed 9 September 2020, <https://mitibmwatsonailab.mit.edu/research/blog/imitation-learning-from-observations-by-minimizing-inverse-dynamics-disagreement/>.
   
   - All Posts n.d., SAIL Blog, viewed 9 September 2020, <https://ai.stanford.edu/blog/>.
   
   - SAIL Blog. (n.d.). All Posts. [online] Available at: https://ai.stanford.edu/blog/.
   
   - Seita, D n.d., The Berkeley Artificial Intelligence Research Blog, The Berkeley Artificial Intelligence Research Blog, viewed 9 September 2020, <https://bair.berkeley.edu/blog/page2/>.


  Cybersecurity:
   - APT1: Exposing One of China’s Cyber Espionage Units. (2013). [online] Available at: https://www.fireeye.com/content/dam/fireeye-www/services/pdfs/mandiant-apt1-report.pdf.
   
   - Five Chinese Military Hackers Charged with Cyber Espionage Against U.S. n.d., Federal Bureau of Investigation, viewed 9 September 2020, <https://www.fbi.gov/news/stories/five-chinese-military-hackers-charged-with-cyber-espionage-against-us>.
   
   - Cisco Umbrella. (2020). What is Cloud Security? [online] Available at: https://umbrella.cisco.com/blog/what-is-cloud-security.
   
   - Mattis, P 2019, CHINESE COMMUNIST ESPIONAGE : an intelligence primer., Naval Inst Press, S.L.
   
   - Gertz, B 2019, Deceiving the sky : inside Communist China’s drive for global supremacy, Encounter Books, New York.


  Autonomous vehicles :
   - Apollo. 2020. Apollo. [ONLINE] Available at: https://apollo.auto/index.html. [Accessed 17 September 2020].

   - Udacity. 2020. Udacity. [ONLINE] Available at: https://classroom.udacity.com/courses/ud0419. [Accessed 17 September 2020].



SHOPMY PTY LTD is a company register in Australia. "SHOPMY", "SHOP N BUY. LET'S SHOPMY" and the logo of SHOPMY are register as a trademark in Australia. SHOPMY PTY LTD 2020 All Right Reserved.

P.S. SHOPMY is finding investor! contact our business team: daivd[at]shopmy.com.au
